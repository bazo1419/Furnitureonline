
package database;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import models.Furniture;

public class TestFurniture {

	static JDBC db;

	@BeforeClass
	public static void init() throws ClassNotFoundException, SQLException {
		db = new JDBC();
		db.setConnection();
	}
	
	@AfterClass
	public static void close() {
		db.closeConnection();
	}
	
	@Test
	public void testGetFurniture() throws SQLException {
		ArrayList<Furniture> list = db.getFurniture("", "Bed", "", "0",
				Integer.toString(Integer.MAX_VALUE));
		assertEquals("Bed", list.get(0).getType());
	}
	
	@Test
	public void testGetFurniture2() throws SQLException {
		ArrayList<Furniture> list = db.getFurniture("", "Gaming", "", "0",
				Integer.toString(Integer.MAX_VALUE));
		assertTrue(list.isEmpty());
	}

	@Test
	public void testGetFurniture3() throws SQLException {
		assertEquals("SportsCar Bed", db.getFurniture(1).getName());
	}

	@Test
	public void testAddFurniture() throws SQLException {
		try {
			db.addFurniture("Plastic Chair", "Chair", "Kids", 10000);
		} catch (SQLException e) {
			System.out.println(e);
		}
		int furniture_id = db
				.getFurniture("Plastic Chair", "Chair", "Kids", "0", "10000")
				.get(0).getId();
		assertEquals("Plastic Chair", db.getFurniture(furniture_id).getName());
	}

	/**
	 * Negative Test Case
	 * @throws SQLException
	 */
	@Test
	public void testDeleteFurniture() throws SQLException {
		assertFalse(db.deleteFurniture(0));
	}
	
	@Test
	public void testEditFurniture() throws SQLException {
		assertEquals(0, db.editFurniture(
				-1, "Plastic Kursi", "Chair", "Kids", 10000));
	}

	@Test
	public void testCheckFurniture() throws SQLException {

		assertTrue(db.checkFurniture("SportsCar Bed"));
	}
}
